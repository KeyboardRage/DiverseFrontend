export const flags = {
  active: 1,
  note: 2,
  warn: 4,
  mute: 8,
  dwc: 16,
  kick: 32,
  tempban: 64,
  ban: 128,
  archived: 256,
};
